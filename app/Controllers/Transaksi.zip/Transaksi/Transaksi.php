<?php

namespace App\Controllers\Transaksi;

use App\Models\TransaksiModel;
use App\Models\DetailTransaksiModel;
use App\Models\BarangModel;
use App\Models\UserModel;
use CodeIgniter\API\ResponseTrait;
use \Firebase\JWT\JWT;
use \Firebase\JWT\Key;
use App\Controllers\BaseController;

class Transaksi extends BaseController
{
    use ResponseTrait;

    protected $transaksiModel;
    protected $detailTransaksiModel;
    protected $barangModel;
    protected $userModel;

    public function __construct()
    {
        $this->transaksiModel = new TransaksiModel();
        $this->detailTransaksiModel = new DetailTransaksiModel();
        $this->barangModel = new BarangModel();
        $this->userModel = new UserModel();
    }

    public function index()
    {
        // Tampilkan halaman transaksi, atau daftar transaksi jika Anda mempunyai halaman dashboard admin
    }

    public function checkout()
    {
        $key = getenv('JWT_SECRET');
        // Ambil token dari header permintaan
        $token = $this->request->getHeaderLine('Authorization');

        // Periksa apakah token ditemukan dalam header permintaan
        if (empty($token)) {
            // Tanggapi jika token tidak ditemukan
            return $this->failUnauthorized('Token not provided.');
        }

        // Buang kata "Bearer " dari token
        $token = str_replace('Bearer ', '', $token);

        // Decode token untuk mendapatkan payload
        try {
            $decoded = JWT::decode($token, new Key($key, 'HS256'));

        } catch (\Exception $e) {
            // Tanggapi jika terjadi kesalahan dalam mendecode token
            return $this->failUnauthorized('Invalid token.');
        }

        // Ambil email dari payload token
        $email = $decoded->email;

        // Ambil pengguna dari database berdasarkan email
        $user = $this->userModel->where('email', $email)->first();

        // Periksa apakah pengguna ditemukan
        if (!$user) {
            return $this->failUnauthorized('User not found.');
        }

        // Ambil pengguna_id dari hasil pencarian
        $user_id = $user['id'];

        // Mendapatkan data keranjang belanjaan pengguna
        $cartItems = $this->getCartItems();

        // Validasi keranjang belanjaan
        if (empty($cartItems)) {
            return $this->fail('Cart is empty. Add items to cart before checkout.');
        }

        // Hitung total belanja
        $total = $this->calculateTotal($cartItems);

        // Buat data transaksi
        $transaksiData = [
            'pengguna_id' => $user_id,
            'total' => $total,
            'status' => 0, // Status 0 untuk belum bayar
        ];

        // Simpan transaksi ke database
        $transaksi = $this->transaksiModel->save($transaksiData);
        if (!$transaksi) {
            return $this->fail('Failed to create transaction.', 500);
        }

        // Dapatkan ID transaksi yang baru saja dibuat
        $transaksi_id = $this->transaksiModel->insertID();

        // Simpan detail transaksi
        foreach ($cartItems as $item) {
            $detailTransaksiData = [
                'transaksi_id' => $transaksi_id, // Menggunakan id dari transaksi yang baru saja dibuat
                'barang_id' => $item['barang_id'],
                'jumlah' => $item['quantity'],
            ];

            $detailTransaksi = $this->detailTransaksiModel->save($detailTransaksiData);
            if (!$detailTransaksi) {
                // Rollback transaksi jika ada kesalahan pada detail transaksi
                $this->transaksiModel->delete($transaksi_id); // Menggunakan id dari transaksi yang baru saja dibuat
                return $this->fail('Failed to create transaction detail.', 500);
            }

            // Kurangi stok barang
            $this->updateStock($item['barang_id'], $item['quantity']);
        }



        // Kosongkan keranjang belanjaan setelah checkout
        $this->clearCart();

        return $this->respondCreated(['message' => 'Checkout successful.']);
    }

    public function addToCart($barang_id)
    {
        // Ambil data JSON dari body permintaan
        $json = $this->request->getJSON();

        // Periksa apakah jumlah yang ditambahkan valid
        $quantity = $json->quantity ?? 1; // Default quantity is 1
        if ($quantity <= 0) {
            return $this->fail('Invalid quantity.', 400);
        }

        // Periksa apakah barang yang ditambahkan ada dalam database
        $barang = $this->barangModel->find($barang_id);
        if (!$barang) {
            return $this->fail('Item not found.', 404);
        }

        // Dapatkan keranjang belanja dari session
        $cartItems = session()->get('cart_items');

        // Tambahkan barang ke keranjang belanja
        $cartItems[$barang_id] = [
            'barang_id' => $barang_id,
            'quantity' => $quantity,
            'nama' => $barang['nama'],
            'harga' => $barang['harga'],
        ];

        // Simpan kembali keranjang belanja ke session
        session()->set('cart_items', $cartItems);

        return $this->respond(['message' => 'Item added to cart successfully.']);
    }

    public function showCart()
    {
        // Ambil data keranjang belanja dari session
        $cartItems = $this->getCartItems();

        // Jika keranjang belanja kosong, kembalikan pesan bahwa keranjang kosong
        if (empty($cartItems)) {
            return $this->fail('Cart is empty.', 404);
        }

        // Lakukan apapun yang diperlukan dengan data keranjang belanja
        // Misalnya, Anda dapat menampilkan data tersebut atau melakukan operasi lain

        return $this->respond($cartItems);
    }


    protected function getCartItems()
    {
        // Misalkan Anda memiliki data keranjang belanja yang disimpan dalam session
        $cartItems = session()->get('cart_items');

        // Periksa apakah keranjang belanjaan tidak kosong
        if (!empty($cartItems)) {
            return $cartItems;
        } else {
            // Jika kosong, kembalikan array kosong
            return [];
        }
    }


    protected function calculateTotal($cartItems)
    {
        $total = 0;
        foreach ($cartItems as $item) {
            $barang = $this->barangModel->find($item['barang_id']);
            $total += $barang['harga'] * $item['quantity'];
        }
        return $total;
    }

    protected function updateStock($barang_id, $quantity)
    {
        $barang = $this->barangModel->find($barang_id);
        $updatedStock = $barang['stok'] - $quantity;
        $this->barangModel->update($barang_id, ['stok' => $updatedStock]);
    }

    protected function clearCart()
    {
        // Logika untuk mengosongkan keranjang belanjaan, Anda bisa menyesuaikan dengan implementasi Anda
    }
}
